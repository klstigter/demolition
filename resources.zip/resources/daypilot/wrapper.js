var dp // global variable for DayPilot Scheduler

function Init() {
    //console.log("function Init() fired.");
    
    var div = document.getElementById("controlAddIn");
    // Ensure full fill
    div.style.width = "100%";
    div.style.height = "100%";
    div.style.margin = "0";
    div.style.padding = "0";
    // Optional: background to test it
    div.style.background = "red";


    dp_element = document.createElement("div");
    dp_element.id = "dp";
    dp_element.name = "dp";
    dp_element.style.width = "100%";
    dp_element.style.height = "100%";
    div.appendChild(dp_element);

    // Notify BC 
    Microsoft.Dynamics.NAV.InvokeExtensibilityMethod("OnAfterInit",[]);
}

function LoadData(resourcesJson, eventsJson) {
    dp = new DayPilot.Scheduler("dp", {
        startDate: "2025-01-01",
        cellGroupBy: "Day", //"Month",
        days: 2, //365,
        scale: "Hour", //"Day"
        showToolTip: true,
        treeEnabled: true,
        dynamicLoading: true,
        
        onEventMoved: async args => {
            console.log("Event moved:", args.e.data);
            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(
                "OnBookingChanged",
                [JSON.stringify(args.e.data)]
            );
        },
        onEventResized: async args => {
            console.log("Event resized:", args.e.data);
            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(
                "OnBookingChanged",
                [JSON.stringify(args.e.data)]
            );
        },
        onTimeRangeSelected: async args =>  {
            console.log("Time range selected:", args);

            var newEvent = {
                id: DayPilot.guid(),
                text: "New Booking",
                start: args.start,
                end: args.end,
                resource: args.resource,
                bubbleHtml: "New Booking"
            };

            rtv = ""
            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(
                "OnBookingCreated",
                [JSON.stringify(newEvent)]
            ); //=> BC will push feedback by function OnBookingCreatedFeedback(rtv, bookingJson) for event creation
        }
    });
    dp.init();
    
    //<<Test data
    // resources_data = (resourcesJson && resourcesJson.trim() !== "") 
    //         ? JSON.parse(resourcesJson) 
    //         : getMockResources();
    // task_data = (eventsJson && eventsJson.trim() !== "") 
    //             ? JSON.parse(eventsJson) 
    //             : getMockEventData();

    // console.log("resources_data: ", resources_data);
    // console.log("task_data: ", task_data);
    //>>

    dp.update({
        resources: (resourcesJson && resourcesJson.trim() !== "") 
                    ? JSON.parse(resourcesJson) 
                    : getMockResources(),
        events: (eventsJson && eventsJson.trim() !== "") 
                ? JSON.parse(eventsJson) 
                : getMockEventData()
    });
}

function OnBookingCreatedFeedback(rtv, bookingJson){
    alert(rtv + " : " + bookingJson);
    if(rtv == "ok")
    {
        dp.events.add(JSON.parse(bookingJson));
    }    
}

// Mock functions for demo
function getMockResources() {
    const resources = [
        { name: "Room A", id: "A" },
        { name: "Room B", id: "B" },
        { name: "Room C", id: "C" },
        { name: "Room D", id: "D" },
        { name: "Room E", id: "E" },
        { name: "Room F", id: "F" },
        { name: "Room G", id: "G" },
        { name: "Room H", id: "H" },
        { name: "Room I", id: "I" }
    ];
    return resources;
    //return JSON.stringify(resources); //if want output as a string
}

function getMockEventData() {
    const events = [];
    for (let i = 0; i < 10; i++) {
        const duration = Math.floor(Math.random() * 3) + 1; // 1-3 hours
        const startOffset = Math.floor(Math.random() * 20); // 0-19 hours

        const start = new DayPilot.Date("2025-01-01T00:00:00").addHours(startOffset);
        const end = start.addHours(duration);

        events.push({
            start: start,
            end: end,
            id: DayPilot.guid(),
            resource: "ABCDEFGHI"[i], // A–I
            text: "Event " + (i + 1),
            bubbleHtml: "Event " + (i + 1)
        });
    }
    return events;
    //return JSON.stringify(events); //if want output as a string
}