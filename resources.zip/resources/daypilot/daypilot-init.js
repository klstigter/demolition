var dp;

window.DayPilotSchedulerInit = function (container) {
    console.log("DayPilotSchedulerInit called");

    // Create scheduler
    dp = new DayPilot.Scheduler(container);

    // Basic configuration
    dp.startDate = DayPilot.Date.today();
    dp.days = 30;
    dp.scale = "Day";
    dp.timeHeaders = [
        { groupBy: "Month" },
        { groupBy: "Day", format: "d" }
    ];
    dp.heightSpec = "Max";
    dp.eventHeight = 30;

    // Event handlers
    dp.onEventMoved = function (args) {
        console.log("Event moved:", args.e.data);
        Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(
            "OnBookingChanged",
            [JSON.stringify(args.e.data)]
        );
    };

    dp.onEventResized = function (args) {
        console.log("Event resized:", args.e.data);
        Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(
            "OnBookingChanged",
            [JSON.stringify(args.e.data)]
        );
    };

    dp.onTimeRangeSelected = function (args) {
        console.log("Time range selected:", args);

        var newEvent = {
            id: DayPilot.guid(),
            text: "New Booking",
            start: args.start,
            end: args.end,
            resource: args.resource
        };

        dp.events.add(newEvent);

        Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(
            "OnBookingCreated",
            [JSON.stringify(newEvent)]
        );

        dp.clearSelection();
    };

    // Draw scheduler
    dp.init();

    // Notify AL that control is ready
    Microsoft.Dynamics.NAV.InvokeExtensibilityMethod("ControlReady", []);

    console.log("Scheduler initialized and ControlReady fired.");
};

// Called from AL
window.LoadData = function (resourcesJson, eventsJson) {
    if (!dp) {
        console.warn("Scheduler not initialized yet, skipping LoadData");
        return;
    }

    console.log("LoadData called from AL");

    var resources = resourcesJson ? JSON.parse(resourcesJson) : [
        { id: "R1", name: "Resource 1" },
        { id: "R2", name: "Resource 2" }
    ];

    var events = eventsJson ? JSON.parse(eventsJson) : [
        {
            id: "E1",
            text: "Test Event",
            start: DayPilot.Date.today(),
            end: DayPilot.Date.today().addDays(1),
            resource: "R1"
        }
    ];

    dp.resources = resources;
    dp.events.list = events;
    dp.update();

    console.log("Scheduler updated with", resources.length, "resources and", events.length, "events.");
};
