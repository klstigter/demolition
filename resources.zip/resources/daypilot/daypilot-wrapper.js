var dp;

// AL will call this to push data into the scheduler
window.LoadData = function (resourcesJson, eventsJson) {
    if (!dp) {
        console.warn("LoadData called but scheduler not initialized yet.");
        return;
    }

    console.log("LoadData received from AL");

    // Parse or use fallback demo data
    var resources = [];
    var events = [];

    try {
        resources = resourcesJson && resourcesJson.length > 0
            ? JSON.parse(resourcesJson)
            : [
                { id: "R1", name: "Resource 1" },
                { id: "R2", name: "Resource 2" }
              ];

        events = eventsJson && eventsJson.length > 0
            ? JSON.parse(eventsJson)
            : [
                {
                    id: "E1",
                    text: "Demo Event",
                    start: DayPilot.Date.today(),
                    end: DayPilot.Date.today().addDays(1),
                    resource: "R1"
                }
              ];
    }
    catch (err) {
        console.error("Error parsing JSON from AL:", err);
        return;
    }

    // Apply data to scheduler
    dp.resources = resources;
    dp.events.list = events;
    dp.update();

    console.log('Scheduler updated with ${resources.length} resources and ${events.length} events.');
};
