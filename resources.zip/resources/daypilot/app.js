!(function () {
  "use strict";
  var e = {
      572: function (e, t, n) {
        n.r(t),
          (t.default =
            '<div class="">\r\n\r\n    <div class="dpw-header">\r\n        <div class="dpw-header-inner">\r\n            <div class="dpw-header-item dpw-header-main"><a href="https://javascript.daypilot.org/">DayPilot Pro for JavaScript</a></div>\r\n            <div class="dpw-header-right">\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class="dpw-subheader">\r\n        <div class="dpw-subheader-inner toolbar">\r\n        </div>\r\n    </div>\r\n\r\n    <div class="dpw-title">\r\n        <div class="dpw-title-inner">\r\n            <div class="download" style="display: flex;">\r\n                <div style="margin-right: 10px;"><a href="https://javascript.daypilot.org/files/daypilot-pro-javascript-trial-2025.3.6631.zip" class="inline-btn"><span>Download</span></a></div>\r\n                <div style="flex-grow: 1;">\r\n                    <div>Download a trial version (1.1 MB).</div>\r\n                    <div><a href="https://javascript.daypilot.org/files/daypilot-pro-javascript-trial-2025.3.6631.zip" class="">daypilot-pro-javascript-trial-2025.3.6631.zip</a></div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class="dpw-main">\r\n        <div class="dpw-sidebar menu">\r\n            <div class="search">\r\n                <div class="search-box"><input type="text" id="search-box-input" placeholder="Quick search"><button id="search-box-clear">&times;</button></div>\r\n            </div>\r\n\r\n        </div>\r\n        <div class="dpw-body">\r\n            <div class="dpw-body-inner">\r\n                <div class="placeholder"></div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div class="dpw-footer">\r\n        <div class="dpw-footer-inner">\r\n        </div>\r\n    </div>\r\n\r\n</div>\r\n');
      },
      722: function (e, t) {
        Object.defineProperty(t, "t", { value: !0 }), (t.i = void 0);
        t.i = (function () {
          function e() {}
          return (
            (e.l =
              navigator &&
              navigator.userAgent &&
              (-1 !== navigator.userAgent.indexOf("MSIE") ||
                -1 !== navigator.userAgent.indexOf("Trident"))),
            e
          );
        })();
      },
      143: function (e, t) {
        Object.defineProperty(t, "t", { value: !0 }), (t.o = void 0);
        var n = (function () {
          function e() {}
          return (
            (e.get = function (e) {
              return document.getElementById(e);
            }),
            (e.query = function (e) {
              return Array.apply(null, document.querySelectorAll(e));
            }),
            (e.m = function (e, t) {
              return e.getElementsByClassName(t)[0];
            }),
            (e.create = function (e) {
              return document.createElement(e);
            }),
            (e.h = function () {
              return document.createDocumentFragment();
            }),
            e
          );
        })();
        t.o = n;
      },
      730: function (e, t) {
        Object.defineProperty(t, "t", { value: !0 }), (t.u = void 0);
        var n = (function () {
          function e() {}
          return (
            (e.prototype.v = function () {
              var e = this;
              document.addEventListener("DOMContentLoaded", function () {
                Array.apply(
                  null,
                  document.querySelectorAll(".track-download")
                ).forEach(function (t) {
                  t.addEventListener("click", function (n) {
                    e.track(t, "/action/trialdownload") || n.preventDefault();
                  });
                });
              });
            }),
            (e.prototype.download = function (e) {
              var t = document.createElement("a");
              (t.href = e),
                (t.download = e.split("/").pop()),
                document.body.appendChild(t),
                t.click(),
                document.body.removeChild(t);
            }),
            (e.prototype.track = function (e, t) {
              var n = this,
                i = window.ga;
              return (
                void 0 !== i && i("send", "pageview", t),
                "_blank" === e.target ||
                  (setTimeout(function () {
                    n.download(e.href);
                  }, 150),
                  !1)
              );
            }),
            e
          );
        })();
        t.u = n;
      },
      447: function (e, t, n) {
        var i =
            (this && this.g) ||
            function (e, t, n, i) {
              return new (n || (n = Promise))(function (l, a) {
                function r(e) {
                  try {
                    m(i.next(e));
                  } catch (e) {
                    a(e);
                  }
                }
                function o(e) {
                  try {
                    m(i.p(e));
                  } catch (e) {
                    a(e);
                  }
                }
                function m(e) {
                  var t;
                  e.done
                    ? l(e.value)
                    : ((t = e.value),
                      t instanceof n
                        ? t
                        : new n(function (e) {
                            e(t);
                          })).then(r, o);
                }
                m((i = i.apply(e, t || [])).next());
              });
            },
          l =
            (this && this.C) ||
            function (e, t) {
              var n,
                i,
                l,
                a,
                r = {
                  label: 0,
                  S: function () {
                    if (1 & l[0]) throw l[1];
                    return l[1];
                  },
                  k: [],
                  T: [],
                };
              return (
                (a = { next: o(0), p: o(1), M: o(2) }),
                "function" == typeof Symbol &&
                  (a[Symbol.iterator] = function () {
                    return this;
                  }),
                a
              );
              function o(o) {
                return function (m) {
                  return (function (o) {
                    if (n)
                      throw new TypeError("Generator is already executing.");
                    for (; a && ((a = 0), o[0] && (r = 0)), r; )
                      try {
                        if (
                          ((n = 1),
                          i &&
                            (l =
                              2 & o[0]
                                ? i.M
                                : o[0]
                                ? i.p || ((l = i.M) && l.call(i), 0)
                                : i.next) &&
                            !(l = l.call(i, o[1])).done)
                        )
                          return l;
                        switch (
                          ((i = 0), l && (o = [2 & o[0], l.value]), o[0])
                        ) {
                          case 0:
                          case 1:
                            l = o;
                            break;
                          case 4:
                            return r.label++, { value: o[1], done: !1 };
                          case 5:
                            r.label++, (i = o[1]), (o = [0]);
                            continue;
                          case 7:
                            (o = r.T.pop()), r.k.pop();
                            continue;
                          default:
                            if (
                              !((l = r.k),
                              (l = l.length > 0 && l[l.length - 1]) ||
                                (6 !== o[0] && 2 !== o[0]))
                            ) {
                              r = 0;
                              continue;
                            }
                            if (
                              3 === o[0] &&
                              (!l || (o[1] > l[0] && o[1] < l[3]))
                            ) {
                              r.label = o[1];
                              break;
                            }
                            if (6 === o[0] && r.label < l[1]) {
                              (r.label = l[1]), (l = o);
                              break;
                            }
                            if (l && r.label < l[2]) {
                              (r.label = l[2]), r.T.push(o);
                              break;
                            }
                            l[2] && r.T.pop(), r.k.pop();
                            continue;
                        }
                        o = t.call(e, r);
                      } catch (e) {
                        (o = [6, e]), (i = 0);
                      } finally {
                        n = l = 0;
                      }
                    if (5 & o[0]) throw o[1];
                    return { value: o[0] ? o[1] : void 0, done: !0 };
                  })([o, m]);
                };
              }
            };
        Object.defineProperty(t, "t", { value: !0 }), (t.R = t.D = void 0);
        var a = n(572),
          r = n(4),
          o = n(143),
          m = n(11),
          s = n(463),
          h = n(730),
          c = n(151),
          u = n(722),
          f = (function () {
            function e() {
              (this.A = 0 === window.location.protocol.indexOf("http")),
                (this.content = o.o.get("content")),
                (this.location = new m.j(
                  window.location.protocol,
                  window.location.host,
                  this.content.dataset.path || window.location.pathname
                )),
                (this.O = {}),
                (this.search = new s.G()),
                (this.H = new r.P()),
                (this._ = new h.u()),
                (this.version = "");
            }
            return (
              (e.prototype.init = function () {
                this.L(), this.V();
              }),
              (e.prototype.L = function () {
                var e = this;
                this.version = this.content.dataset.version;
                var t = o.o.create("div");
                t.innerHTML = a.default;
                var n = null;
                if (this.location.W) document.body.className = "dpw-no-sidebar";
                else {
                  var i = o.o.m(t, "menu"),
                    l = this.N();
                  i.appendChild(l);
                  var r = function () {
                    l.scrollHeight <= l.offsetHeight
                      ? (i.classList.add("no-gradient-bottom"),
                        i.classList.add("no-gradient-top"))
                      : (l.scrollTop + l.offsetHeight >= l.scrollHeight
                          ? i.classList.add("no-gradient-bottom")
                          : i.classList.remove("no-gradient-bottom"),
                        0 == l.scrollTop
                          ? i.classList.add("no-gradient-top")
                          : i.classList.remove("no-gradient-top"));
                  };
                  r(),
                    l.addEventListener("scroll", r),
                    window.addEventListener("resize", r),
                    new MutationObserver(r).observe(l, {
                      childList: !0,
                      subtree: !0,
                    }),
                    l.addEventListener("mouseover", function (t) {
                      var n = t.target;
                      if ("A" === n.tagName) {
                        var i = n.getAttribute("href");
                        i && e.F(i);
                      }
                    }),
                    l.addEventListener(
                      "touchstart",
                      function (t) {
                        var n = t.target;
                        if ("A" === n.tagName) {
                          var i = n.getAttribute("href");
                          i && e.F(i);
                        }
                      },
                      { passive: !0 }
                    ),
                    (n = l.querySelector(".active")),
                    (document.body.className = "dpw-sidebar-left");
                }
                var m = o.o.m(t, "toolbar"),
                  s = this.B();
                m.appendChild(s);
                var h = o.o.m(t, "placeholder");
                (this.placeholder = h),
                  h.appendChild(this.J(document)),
                  u.i.l
                    ? h.appendChild(this.content)
                    : h.appendChild(this.content.content),
                  new c.Y(this.placeholder).I(),
                  document.body.insertBefore(t, document.body.firstChild),
                  this.search.v(),
                  n && this.q(n),
                  this.location.K && !this.location.sandbox && this._.v();
              }),
              (e.prototype.J = function (e) {
                var t = e.title.split("|")[0].trim(),
                  n = e.createElement("h2");
                return (n.className = "title"), (n.innerHTML = t), n;
              }),
              (e.prototype.q = function (e) {
                var t = document.querySelector(".dp-menu");
                if (t) {
                  var n = t.getBoundingClientRect(),
                    i = e.getBoundingClientRect();
                  i.top < n.top
                    ? (t.scrollTop -= n.top - i.top + 45)
                    : i.bottom > n.bottom &&
                      (t.scrollTop += i.bottom - n.bottom + 85);
                }
              }),
              (e.prototype.N = function () {
                var e = this,
                  t = o.o.create("div");
                t.className = "dp-menu";
                var n = o.o.create("ul"),
                  i = this.location.$;
                return (
                  this.H.getItems(i).forEach(function (t) {
                    var i = t.filename;
                    "index.html" !== i || e.location.filesystem || (i = "./");
                    var l = e.U(
                      t.text,
                      i,
                      t.filename === e.location.filename,
                      t.Z,
                      t.standalone
                    );
                    n.appendChild(l.div);
                  }),
                  t.appendChild(n),
                  t
                );
              }),
              (e.prototype.U = function (e, t, n, i, l) {
                var a = this,
                  r = o.o.create("li");
                if ("string" == typeof t) {
                  var m = document.createElement("a");
                  if (
                    ((m.href = t),
                    (m.title = e),
                    n && (m.className = "active"),
                    this.A &&
                      m.addEventListener("click", function (e) {
                        window.innerWidth <= 1e3 ||
                          l ||
                          (e.preventDefault(), a.X(t));
                      }),
                    i)
                  ) {
                    var s = o.o.create("span");
                    (s.innerText = "NEW"),
                      (s.className = "new"),
                      m.appendChild(s);
                  }
                  var h = o.o.create("span");
                  (h.innerText = e), m.appendChild(h), r.appendChild(m);
                } else {
                  var c = o.o.create("strong");
                  (c.innerText = e), r.appendChild(c);
                }
                return { div: r };
              }),
              (e.prototype.B = function () {
                var e = this,
                  t = o.o.h(),
                  n = this.location.W ? "" : "../",
                  i = this.location.filesystem ? "index.html" : "",
                  l = this.location.sandbox ? "Sandbox" : "Demo",
                  a = this.ee(l, n + i, this.location.W);
                return (
                  t.appendChild(a.div),
                  this.H.te().forEach(function (l) {
                    var a = "".concat(n).concat(l.$, "/").concat(i),
                      r = l.$ === e.location.$,
                      o = e.ee(l.text, a, r);
                    t.appendChild(o.div);
                  }),
                  t
                );
              }),
              (e.prototype.ee = function (e, t, n) {
                var i = o.o.create("div");
                i.className = "dpw-header-item";
                var l = document.createElement("a");
                return (
                  (l.href = t),
                  (l.innerText = e),
                  n && (l.className = "dpw-header-item-selected"),
                  i.appendChild(l),
                  { div: i, a: l }
                );
              }),
              (e.prototype.V = function () {
                var e = this;
                window.addEventListener("popstate", function (t) {
                  var n = window.location.pathname,
                    i = n.substring(n.lastIndexOf("/") + 1);
                  ("" !== i && "index.html" !== i) || (i = "./"), e.X(i, !0);
                });
              }),
              (e.prototype.F = function (e) {
                return i(this, void 0, void 0, function () {
                  var t, n, i, a;
                  return l(this, function (l) {
                    switch (l.label) {
                      case 0:
                        return this.O[e] && !this.O[e].ne()
                          ? [2, this.O[e]]
                          : ((t = this.A
                              ? e +
                                (-1 === e.indexOf("?") ? "?" : "&") +
                                "v=" +
                                this.version
                              : e),
                            [4, fetch(t)]);
                      case 1:
                        return (n = l.S()).ok ? [4, n.text()] : [2, null];
                      case 2:
                        return -1 === (i = l.S()).indexOf("<!DOCTYPE html>")
                          ? [2, null]
                          : ((a = new v(i)),
                            this.ie(a.le),
                            this.ae(a.le),
                            (this.O[e] = a),
                            [2, a]);
                    }
                  });
                });
              }),
              (e.prototype.X = function (e, t) {
                return i(this, void 0, void 0, function () {
                  var n, i, a, r, m, s, h, u, f, v, d;
                  return l(this, function (l) {
                    switch (l.label) {
                      case 0:
                        return (
                          (n = window.location.href),
                          (i = this.O[e]) ? [3, 2] : [4, this.F(e)]
                        );
                      case 1:
                        (i = l.S()), (l.label = 2);
                      case 2:
                        return i
                          ? ((a = i.le),
                            (r = a.querySelector("#content").content),
                            this.ie(a),
                            r.querySelectorAll("script").forEach(function (e) {
                              var t = e.parentNode,
                                n = document.createElement("script");
                              (n.innerHTML = "(function() {".concat(
                                e.innerHTML,
                                "})();"
                              )),
                                t.replaceChild(n, e);
                            }),
                            (this.placeholder.innerHTML = ""),
                            this.placeholder.appendChild(this.J(a)),
                            this.placeholder.appendChild(r),
                            (m = a.querySelector("script[src*='jquery']")) &&
                              (s = m.getAttribute("src")) &&
                              (document.querySelector(
                                'script[src="'.concat(s, '"]')
                              ) ||
                                ((h =
                                  document.createElement(
                                    "script"
                                  )).setAttribute("src", s),
                                document.head.appendChild(h))),
                            new c.Y(this.placeholder).I(),
                            (u = a.querySelector("title")),
                            (document.title = u.innerText),
                            t || window.history.pushState({}, "", e),
                            this.search.v(),
                            (f = o.o.m(document.body, "dp-menu")),
                            (v = f.querySelector("a.active")) &&
                              v.classList.remove("active"),
                            (d = f.querySelector('a[href="'.concat(e, '"]'))) &&
                              (d.classList.add("active"), this.q(d)),
                            this.re({ referrer: n }),
                            [2])
                          : [2];
                    }
                  });
                });
              }),
              (e.prototype.re = function (e) {
                var t = window.__sendPageView;
                t && t(window.location.href, e);
              }),
              (e.prototype.ie = function (e) {
                e.querySelectorAll("link[rel=stylesheet]").forEach(function (
                  e
                ) {
                  var t = e.getAttribute("href");
                  if (
                    t &&
                    !document.querySelector('link[href="'.concat(t, '"]'))
                  ) {
                    var n = document.createElement("link");
                    n.setAttribute("rel", "stylesheet"),
                      n.setAttribute("href", t),
                      document.head.appendChild(n);
                  }
                });
              }),
              (e.prototype.ae = function (e) {
                e.querySelectorAll("script").forEach(function (e) {
                  var t = e.getAttribute("src");
                  if (t) {
                    var n = t.split("?")[0];
                    if (
                      !Array.from(
                        document.querySelectorAll("script[src]")
                      ).find(function (e) {
                        var t = e.getAttribute("src");
                        return t && t.split("?")[0] === n;
                      })
                    ) {
                      var i = document.createElement("script");
                      i.setAttribute("src", t), document.head.appendChild(i);
                    }
                  }
                });
              }),
              e
            );
          })();
        t.D = f;
        var v = (function () {
          function e(e) {
            (this.oe = new Date()), (this.me = e);
          }
          return (
            (e.prototype.ne = function () {
              return new Date().getTime() - this.oe.getTime() > 36e5;
            }),
            Object.defineProperty(e.prototype, "le", {
              get: function () {
                return new DOMParser().parseFromString(this.me, "text/html");
              },
              enumerable: !1,
              configurable: !0,
            }),
            e
          );
        })();
        t.R = v;
      },
      11: function (e, t) {
        Object.defineProperty(t, "t", { value: !0 }), (t.j = void 0);
        var n = (function () {
          function e(e, t, n) {
            (this.se = ["demo", "demo2", "sandbox"]),
              (this.pathname = n),
              (this.host = t),
              (this.protocol = e),
              this.he();
          }
          return (
            Object.defineProperty(e.prototype, "W", {
              get: function () {
                return "ROOT" === this.$;
              },
              enumerable: !1,
              configurable: !0,
            }),
            (e.test = function () {}),
            (e.prototype.he = function () {
              (this.filename = this.ce(this.pathname)),
                (this.$ = this.ue(this.pathname)),
                (this.sandbox = this.fe(this.pathname)),
                (this.K = this.ve(this.host)),
                (this.filesystem = this.de(this.protocol));
            }),
            (e.prototype.ce = function (e) {
              var t = e.substring(e.lastIndexOf("/") + 1);
              return "" === t && (t = "index.html"), t;
            }),
            (e.prototype.de = function (e) {
              return "file:" === e;
            }),
            (e.prototype.ue = function (e) {
              var t = e.lastIndexOf("/"),
                n = e.lastIndexOf("/", t - 1),
                i = e.substring(n + 1, t);
              return (
                "/" === i && (i = "ROOT"),
                -1 !== this.se.indexOf(i) && (i = "ROOT"),
                i
              );
            }),
            (e.prototype.ve = function (e) {
              return "javascript.daypilot.org" === e;
            }),
            (e.prototype.fe = function (e) {
              return 0 === e.indexOf("/sandbox");
            }),
            (e.prototype.print = function () {
              window.console.log(this.pathname, this.$, this.filename);
            }),
            e
          );
        })();
        t.j = n;
      },
      463: function (e, t, n) {
        Object.defineProperty(t, "t", { value: !0 }), (t.G = void 0);
        var i = n(143),
          l = (function () {
            function e() {
              this.xe = null;
            }
            return (
              (e.prototype.v = function () {
                var e = this,
                  t = (this.ge = i.o.get("search-box-input"));
                t.addEventListener("keyup", function (n) {
                  ("Escape" !== n.key && "Esc" !== n.key) || (t.value = ""),
                    e.pe(t.value);
                }),
                  i.o
                    .get("search-box-clear")
                    .addEventListener("click", function (n) {
                      e.we(), t.focus();
                    });
              }),
              (e.prototype.we = function () {
                (this.ge.value = ""), this.pe("");
              }),
              (e.prototype.pe = function (e) {
                var t = !e || "" === e.trim();
                t ? this.be() : this.Ee(),
                  i.o.query(".menu li").forEach(function (n) {
                    var i = n.getElementsByTagName("a")[0],
                      l =
                        i &&
                        -1 !==
                          i.innerText.toLowerCase().indexOf(e.toLowerCase()),
                      a = t || l;
                    n.style.display = a ? "" : "none";
                  });
              }),
              (e.prototype.Ee = function () {
                if (null == this.xe) {
                  var e = this.ye();
                  e &&
                    ((this.xe = e.offsetHeight),
                    (e.style.height = this.xe + "px"));
                }
              }),
              (e.prototype.be = function () {
                var e = this.ye();
                (this.xe = null), e && (e.style.height = "");
              }),
              (e.prototype.ye = function () {
                return i.o.query(".dp-menu")[0];
              }),
              e
            );
          })();
        t.G = l;
      },
      151: function (e, t, n) {
        Object.defineProperty(t, "t", { value: !0 }), (t.Y = void 0);
        var i = n(143),
          l = n(827),
          a = n(722),
          r = (function () {
            function e(e) {
              this.placeholder = e;
            }
            return (
              (e.prototype.I = function () {
                if (null !== this.Ce()) {
                  var e = this.Se();
                  this.placeholder.appendChild(e);
                }
              }),
              (e.prototype.Se = function () {
                var e = this,
                  t = i.o.create("div");
                t.className = "space";
                var n = i.o.create("button");
                return (
                  (n.className = "button-source"),
                  (n.innerText = "Show source"),
                  (n.onclick = function () {
                    e.ke(), (n.style.display = "none");
                  }),
                  t.appendChild(n),
                  t
                );
              }),
              (e.prototype.ke = function () {
                var e,
                  t = this.Ce(),
                  n = a.i.l ? t.innerText : t.innerHTML,
                  r = n;
                if (n.startsWith("(function() {")) {
                  var o = n.indexOf("(function() {"),
                    m = n.lastIndexOf("})();");
                  r = n.substring(o + 13, m);
                }
                a.i.l
                  ? (((e = i.o.create("div")).innerHTML =
                      "<pre>" + l.Me.Te(r) + "</pre>"),
                    this.placeholder.appendChild(e))
                  : (((e = i.o.create("pre")).innerText = l.Me.Te(r)),
                    this.placeholder.appendChild(e));
              }),
              (e.prototype.Ce = function () {
                return this.placeholder.querySelector("script:not([src])");
              }),
              e
            );
          })();
        t.Y = r;
      },
      4: function (e, t) {
        Object.defineProperty(t, "t", { value: !0 }), (t.P = void 0);
        var n = [
            {
              text: "Calendar",
              $: "calendar",
              children: [
                { text: "Main" },
                { text: "JavaScript Event Calendar", filename: "index.html" },
                { text: "Navigation" },
                { text: "Navigator", filename: "navigator.html" },
                { text: "Date Picker", filename: "datepicker.html" },
                { text: "Next/Previous", filename: "nextprevious.html" },
                { text: "Themes" },
                { text: "Green Theme", filename: "themegreen.html" },
                {
                  text: "Transparent Theme",
                  filename: "themetransparent.html",
                },
                { text: "White Theme", filename: "themewhite.html" },
                {
                  text: "Traditional Theme",
                  filename: "themetraditional.html",
                },
                { text: "Events" },
                { text: "All-Day Events", filename: "allday.html" },
                { text: "Active Areas", filename: "eventareas.html" },
                { text: "Event Context Menu", filename: "eventmenu.html" },
                {
                  text: "Event Customization",
                  filename: "eventcustomization.html",
                },
                { text: "Event Deleting", filename: "eventdeleting.html" },
                { text: "Event Filtering", filename: "eventfiltering.html" },
                {
                  text: "Event Moving Customization",
                  filename: "eventmovingcustomization.html",
                },
                { text: "Event Overlaps", filename: "eventoverlaps.html" },
                {
                  text: "Event Resizing Customization",
                  filename: "eventresizingcustomization.html",
                },
                { text: "Event Selecting", filename: "eventselecting.html" },
                { text: "External Drag and Drop", filename: "external.html" },
                {
                  text: "Progressive Event Rendering",
                  filename: "eventsprogressive.html",
                },
                { text: "Queue", filename: "queue.html", Z: !0 },
                { text: "Resource Calendar" },
                { text: "Scale: Hours", filename: "scalehours.html", Z: !0 },
                { text: "Scale: Days", filename: "scaledays.html", Z: !0 },
                { text: "Scale: Weeks", filename: "scaleweeks.html", Z: !0 },
                { text: "Scale: Custom", filename: "scalecustom.html", Z: !0 },
                { text: "Column Filtering", filename: "columnfiltering.html" },
                { text: "Custom Column Width", filename: "columnwidth.html" },
                { text: "Column Moving", filename: "columnmoving.html" },
                { text: "Column Resizing", filename: "columnresizing.html" },
                { text: "Grid" },
                { text: "50 columns", filename: "50columns.html" },
                { text: "100% height", filename: "100pctheight.html" },
                { text: "Crosshair", filename: "crosshair.html" },
                { text: "Disabled Cells", filename: "cellsdisabled.html" },
                { text: "Snap to Grid", filename: "snaptogrid.html", Z: !0 },
                {
                  text: "Time Range Selecting",
                  filename: "timerangeselecting.html",
                },
                { text: "Zoom", filename: "zoom.html" },
                { text: "Localization" },
                { text: "Localization", filename: "localization.html" },
                { text: "RTL", filename: "rtl.html" },
                { text: "Timeline" },
                { text: "Overnight Shift", filename: "overnight.html" },
                { text: "Lunch Break", filename: "lunchbreak.html" },
                {
                  text: "Time Header Cell Duration",
                  filename: "timeheadercellduration.html",
                },
                { text: "Export" },
                { text: "JPEG Export", filename: "exportjpeg.html" },
                { text: "SVG Export", filename: "exportsvg.html" },
                { text: "Frameworks" },
                { text: "Angular", filename: "angular.html" },
                { text: "React", filename: "react.html" },
                { text: "Vue", filename: "vue.html" },
                { text: "View Types" },
                { text: "Day View", filename: "day.html" },
                { text: "Week View", filename: "week.html" },
                { text: "Year View", filename: "year.html", Z: !0 },
                { text: "Resources", filename: "resources.html" },
                { text: "Resource Hierarchy", filename: "hierarchy.html" },
                { text: "Days-Resources", filename: "daysresources.html" },
              ],
            },
            {
              text: "Month",
              $: "month",
              children: [
                { text: "Main" },
                {
                  text: "JavaScript Monthly Event Calendar",
                  filename: "index.html",
                },
                { text: "Navigation" },
                { text: "Navigator", filename: "navigator.html" },
                { text: "Date Picker", filename: "datepicker.html" },
                { text: "Next/Previous", filename: "nextprevious.html" },
                { text: "Themes" },
                { text: "Green Theme", filename: "themegreen.html" },
                {
                  text: "Transparent Theme",
                  filename: "themetransparent.html",
                },
                { text: "White Theme", filename: "themewhite.html" },
                {
                  text: "Traditional Theme",
                  filename: "themetraditional.html",
                },
                { text: "Events" },
                { text: "Event Active Areas", filename: "eventareas.html" },
                { text: "Event Context Menu", filename: "eventmenu.html" },
                { text: "Event Deleting", filename: "eventdeleting.html" },
                { text: "Event Filtering", filename: "eventfiltering.html" },
                {
                  text: "Event Customization",
                  filename: "eventcustomization.html",
                },
                { text: "Event Position", filename: "eventposition.html" },
                { text: "Event Selecting", filename: "eventselecting.html" },
                {
                  text: "Event Start and End Time",
                  filename: "eventstartend.html",
                },
                { text: "Event End Spec", filename: "eventendspec.html" },
                { text: "External Drag and Drop", filename: "external.html" },
                { text: "Max Events", filename: "eventsmax.html" },
                { text: "Grid" },
                { text: "Cell Icons", filename: "cellicons.html", Z: !0 },
                { text: "Disabled Cells", filename: "cellsdisabled.html" },
                { text: "Highlighting Today", filename: "today.html" },
                { text: "Export" },
                { text: "JPEG Export", filename: "exportjpeg.html" },
                { text: "SVG Export", filename: "exportsvg.html" },
                { text: "Frameworks" },
                { text: "Angular", filename: "angular.html" },
                { text: "React", filename: "react.html" },
                { text: "Vue", filename: "vue.html" },
                { text: "Appearance" },
                { text: "100% Height", filename: "100pctheight.html" },
                { text: "View Types" },
                { text: "Weeks", filename: "weeks.html" },
                { text: "Localization" },
                { text: "Localization", filename: "localization.html" },
                { text: "RTL", filename: "rtl.html", Z: !0 },
              ],
            },
            {
              text: "Scheduler",
              $: "scheduler",
              children: [
                { text: "Main" },
                { text: "JavaScript Scheduler", filename: "index.html" },
                { text: "Timeline" },
                {
                  text: "Active Areas",
                  filename: "timeheaderactiveareas.html",
                },
                { text: "Time Headers", filename: "timeheaders.html" },
                {
                  text: "Time Header Bubble",
                  filename: "timeheaderbubble.html",
                  Z: !0,
                },
                { text: "Hiding Weekends", filename: "hide.html" },
                {
                  text: "Hiding Non-Business Hours",
                  filename: "hidingnonbusiness.html",
                },
                { text: "Separators", filename: "separators.html" },
                { text: "Scale: Minutes", filename: "scaleminutes.html" },
                { text: "Scale: Hours", filename: "scalehours.html" },
                { text: "Scale: Days", filename: "scaledays.html" },
                { text: "Scale: Weeks", filename: "scaleweeks.html" },
                { text: "Scale: Months", filename: "scalemonths.html" },
                { text: "Scale: Years", filename: "scaleyears.html" },
                { text: "Scale: Custom", filename: "scalecustom.html" },
                { text: "Frameworks" },
                { text: "Angular", filename: "angular.html" },
                { text: "React", filename: "react.html" },
                { text: "Vue.js", filename: "vuejs.html" },
                { text: "View Types" },
                { text: "Gantt Chart", filename: "gantt.html" },
                { text: "Timesheet", filename: "timesheet.html" },
                { text: "Year View", filename: "year.html", Z: !0 },
                { text: "Rows" },
                { text: "Resource Tree", filename: "tree.html" },
                {
                  text: "Custom Event Height",
                  filename: "roweventheight.html",
                },
                { text: "Dynamic Tree Loading", filename: "treedynamic.html" },
                {
                  text: "External Drag and Drop of Rows",
                  filename: "externalrow.html",
                  Z: !0,
                },
                { text: "Frozen Rows", filename: "rowsfrozen.html" },
                {
                  text: "Progressive Rendering",
                  filename: "rowprogressive.html",
                },
                {
                  text: "Resource Utilization",
                  filename: "resourceutilization.html",
                },
                { text: "Row Creating", filename: "rowcreating.html" },
                { text: "Row Editing", filename: "rowediting.html" },
                { text: "Row Filtering", filename: "rowfiltering.html" },
                {
                  text: "Row Header Active Areas",
                  filename: "rowheaderactiveareas.html",
                },
                {
                  text: "Row Header Columns",
                  filename: "rowheadercolumns.html",
                },
                { text: "Row Header Hiding", filename: "rowheaderhiding.html" },
                {
                  text: "Row Header Scrolling",
                  filename: "rowheaderscrolling.html",
                },
                { text: "Row Moving", filename: "rowmoving.html" },
                {
                  text: "Row Moving between Schedulers",
                  filename: "rowmovingtwoschedulers.html",
                  Z: !0,
                },
                { text: "Row Selecting", filename: "rowselecting.html" },
                { text: "Row Sorting", filename: "rowsorting.html" },
                { text: "Split Resources", filename: "split.html", Z: !0 },
                { text: "Events" },
                {
                  text: "Asynchronous Validation",
                  filename: "asyncvalidation.html",
                },
                {
                  text: "Group Concurrent Events",
                  filename: "groupconcurrent.html",
                },
                { text: "Dynamic Event Loading", filename: "dynamic.html" },
                { text: "Event Active Areas", filename: "eventareas.html" },
                { text: "Event Containers", filename: "eventcontainers.html" },
                { text: "Event Context Menu", filename: "eventmenu.html" },
                { text: "Event Copying", filename: "eventcopying.html" },
                {
                  text: "Event Customization",
                  filename: "eventcustomization.html",
                },
                { text: "Event Deleting", filename: "eventdeleting.html" },
                { text: "Event Filtering", filename: "eventfiltering.html" },
                { text: "Event Height", filename: "eventheight.html" },
                { text: "Event Icons", filename: "eventicons.html" },
                {
                  text: "Event Inline Editing",
                  filename: "eventinlineediting.html",
                },
                { text: "Event Links", filename: "eventlinks.html" },
                { text: "Event Loading", filename: "eventloading.html" },
                { text: "Event Moving", filename: "eventmoving.html" },
                {
                  text: "Event Moving (Non-Business)",
                  filename: "eventmovingnonbusiness.html",
                },
                {
                  text: "Event Moving between Schedulers",
                  filename: "eventmovingtwoschedulers.html",
                },
                {
                  text: "Event Multi-Moving",
                  filename: "eventmultimoving.html",
                },
                {
                  text: "Event Multi-Resizing",
                  filename: "eventmultiresizing.html",
                },
                {
                  text: "Event Multi-Selecting",
                  filename: "eventmultiselecting.html",
                },
                {
                  text: "Event Overlapping",
                  filename: "eventoverlapping.html",
                },
                { text: "Event Phases", filename: "eventphases.html" },
                { text: "Event Searching", filename: "eventsearching.html" },
                { text: "Event Selecting", filename: "eventselecting.html" },
                {
                  text: "Event Stacking Line Height",
                  filename: "eventstackinglineheight.html",
                },
                { text: "Event Versions", filename: "eventversions.html" },
                {
                  text: "External Drag and Drop of Events",
                  filename: "external.html",
                },
                { text: "Joint Events", filename: "eventsjoint.html" },
                { text: "Milestones", filename: "milestones.html" },
                { text: "Percent Complete", filename: "eventcomplete.html" },
                { text: "Queue", filename: "queue.html" },
                {
                  text: "Real-Time Drag and Drop Indicators",
                  filename: "eventrealtime.html",
                },
                { text: "Grid" },
                {
                  text: "Cell Customization",
                  filename: "cellcustomization.html",
                },
                { text: "Cell Width", filename: "cellwidth.html" },
                { text: "Auto Cell Width", filename: "autocellwidth.html" },
                { text: "Crosshair", filename: "crosshair.html" },
                { text: "Disabled Cells", filename: "cellsdisabled.html" },
                {
                  text: "Highlighting Unavailable Cells",
                  filename: "unavailable.html",
                },
                {
                  text: "Highlighting Weekends",
                  filename: "highlighting.html",
                },
                { text: "Infinite Scrolling", filename: "infinite.html" },
                { text: "Keyboard Access", filename: "keyboard.html" },
                { text: "Multi-Range Selecting", filename: "multirange.html" },
                { text: "Scrolling", filename: "scrolling.html" },
                { text: "Snap to Grid", filename: "snaptogrid.html" },
                {
                  text: "Time Range Selecting",
                  filename: "timerangeselecting.html",
                },
                { text: "Navigation" },
                { text: "Navigator", filename: "navigator.html" },
                {
                  text: "Next/Previous Buttons",
                  filename: "nextprevious.html",
                },
                { text: "Export" },
                {
                  text: "Excel Export",
                  filename: "exportexcel.html",
                  Z: !0,
                  standalone: !0,
                },
                { text: "JPEG Export", filename: "exportjpg.html" },
                { text: "PNG Export", filename: "exportpng.html" },
                { text: "SVG Export", filename: "exportsvg.html" },
                { text: "Printing", filename: "exportprint.html" },
                { text: "Localization" },
                { text: "Localization", filename: "localization.html" },
                { text: "Themes" },
                {
                  text: "Transparent Theme",
                  filename: "themetransparent.html",
                },
                { text: "White Theme", filename: "themewhite.html" },
                { text: "Green Theme", filename: "themegreen.html" },
                { text: "Theme 8", filename: "theme8.html" },
                {
                  text: "Traditional Theme",
                  filename: "themetraditional.html",
                },
                { text: "Blue Theme", filename: "themeblue.html" },
                { text: "Controls" },
                { text: "Message Bar", filename: "messagebar.html" },
              ],
            },
            {
              text: "Gantt",
              $: "gantt",
              children: [
                { text: "Main" },
                { text: "JavaScript Gantt", filename: "index.html" },
                { text: "Rows" },
                { text: "Row Editing", filename: "rowediting.html" },
                { text: "Row Filtering", filename: "rowfiltering.html" },
                { text: "Row Selecting", filename: "rowselecting.html" },
                {
                  text: "Task Moving between Gantt Charts",
                  filename: "taskmovingtwoganttcharts.html",
                  Z: !0,
                },
                {
                  text: "External Drag and Drop",
                  filename: "external.html",
                  Z: !0,
                },
                { text: "Tasks" },
                { text: "Task Bubble", filename: "taskbubble.html" },
                {
                  text: "Task Children Moving",
                  filename: "taskmovingchildren.html",
                  Z: !0,
                },
                { text: "Task Creating", filename: "taskcreating.html" },
                {
                  text: "Task Multi-Moving",
                  filename: "taskmultimoving.html",
                  Z: !0,
                },
                {
                  text: "Task Multi-Selecting",
                  filename: "taskmultiselecting.html",
                  Z: !0,
                },
                { text: "Task Resizing", filename: "taskresizing.html" },
                { text: "Task Versions", filename: "taskversions.html" },
                { text: "Progressive Rendering", filename: "progressive.html" },
                { text: "Export" },
                {
                  text: "Excel Export",
                  filename: "exportexcel.html",
                  Z: !0,
                  standalone: !0,
                },
                { text: "PNG Export", filename: "exportpng.html" },
                { text: "SVG Export", filename: "exportsvg.html" },
                { text: "Links" },
                { text: "Links", filename: "links.html" },
                { text: "Grid" },
                { text: "Auto Cell Width", filename: "autocellwidth.html" },
                { text: "Frameworks" },
                { text: "Angular", filename: "angular.html" },
              ],
            },
            {
              text: "Kanban",
              $: "kanban",
              children: [
                { text: "JavaScript Kanban", filename: "index.html" },
                { text: "Columns" },
                {
                  text: "Column Active Areas",
                  filename: "columnactiveareas.html",
                },
                { text: "Column Moving", filename: "columnmoving.html" },
                {
                  text: "Fixed Column Width",
                  filename: "columnfixedwidth.html",
                },
                { text: "Cards" },
                { text: "Card Active Areas", filename: "cardactiveareas.html" },
                { text: "Card Auto Height", filename: "cardautoheight.html" },
                { text: "Card Bubble", filename: "cardbubble.html", Z: !0 },
                { text: "Card Context Menu", filename: "cardcontextmenu.html" },
                { text: "Card Creating", filename: "cardcreating.html" },
                { text: "Card CSS", filename: "cardcss.html" },
                { text: "Card Deleting", filename: "carddeleting.html" },
                { text: "Card Moving", filename: "cardmoving.html" },
                {
                  text: "Card Moving Customization",
                  filename: "cardmovingcustomization.html",
                  Z: !0,
                },
                { text: "External Drag and Drop", filename: "external.html" },
                { text: "Swimlanes" },
                { text: "Swimlanes", filename: "swimlanes.html" },
                { text: "Swimlane Moving", filename: "swimlanemoving.html" },
                {
                  text: "Swimlane Collapsing",
                  filename: "swimlanecollapsing.html",
                },
                {
                  text: "Row Header Columns",
                  filename: "rowheadercolumns.html",
                  Z: !0,
                },
                { text: "Frameworks" },
                { text: "Angular", filename: "angular.html" },
              ],
            },
          ],
          i = (function () {
            function e() {
              (this.Re = {}), this.load();
            }
            return (
              (e.prototype.getItems = function (e) {
                var t, n;
                return null !==
                  (n =
                    null === (t = this.Re[e]) || void 0 === t
                      ? void 0
                      : t.children) && void 0 !== n
                  ? n
                  : [];
              }),
              (e.prototype.te = function () {
                return n;
              }),
              (e.prototype.load = function () {
                var e = this;
                n.forEach(function (t) {
                  (t.f = t.$), (e.Re[t.$] = t);
                }),
                  (window._structure = n);
              }),
              e
            );
          })();
        t.P = i;
      },
      827: function (e, t) {
        Object.defineProperty(t, "t", { value: !0 }), (t.Me = void 0);
        var n = (function () {
          function e() {}
          return (
            (e.Te = function (e) {
              var t = this,
                n = e.split(/\r?\n/),
                i = 100;
              n.forEach(function (e) {
                if (!(0 === e.trim().length)) {
                  var n = t.ze(e);
                  n < i && (i = n);
                }
              });
              var l = n.map(function (e) {
                  return 0 === e.trim().length ? "" : e.substring(i);
                }),
                a = !1;
              return l
                .filter(function (e) {
                  var t = 0 === e.trim().length;
                  return !(!a && t) && ((a = !0), !0);
                })
                .join("\n");
            }),
            (e.ze = function (t) {
              var n = 0;
              return (
                e.De(t).some(function (e) {
                  if (" " !== e) return !0;
                  n += 1;
                }),
                n
              );
            }),
            (e.De = function (e) {
              return e.split("");
            }),
            e
          );
        })();
        t.Me = n;
      },
    },
    t = {};
  function n(i) {
    var l = t[i];
    if (void 0 !== l) return l.exports;
    var a = (t[i] = { exports: {} });
    return e[i].call(a.exports, a, a.exports, n), a.exports;
  }
  n.r = function (e) {
    "undefined" != typeof Symbol &&
      Symbol.toStringTag &&
      Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
      Object.defineProperty(e, "t", { value: !0 });
  };
  new (n(447).D)().init();
})();
