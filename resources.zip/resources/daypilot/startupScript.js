Microsoft.Dynamics.NAV.InvokeExtensibilityMethod("ControlReady",[]);
//console.log("ControlReady fired.");